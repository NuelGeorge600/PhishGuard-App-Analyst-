# Entry point for the Flask app
