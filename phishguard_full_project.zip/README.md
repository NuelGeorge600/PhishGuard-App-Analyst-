# PhishGuard Full Project Manual Deployment
