# Flask app entry point with Gunicorn compatibility
