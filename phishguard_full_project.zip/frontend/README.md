# React frontend setup instructions
