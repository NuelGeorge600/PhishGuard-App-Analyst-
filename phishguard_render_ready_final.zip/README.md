# PhishGuard Deploy Instructions

Set environment variables on Render UI as per .env.example
