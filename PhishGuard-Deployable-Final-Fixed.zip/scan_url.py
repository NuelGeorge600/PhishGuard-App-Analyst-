# Logic for Scam Website Detector
