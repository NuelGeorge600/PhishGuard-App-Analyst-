
# PhishGuard 🚀

A phishing defense system with:
- Scam Website Detector (VirusTotal)
- Email Header Analyzer
- ₦50,000/event Pay-per-click logic
- Admin analytics dashboard
- Full Flutterwave webhook integration

## 🚀 Deploy on Render (Free Tier)

- **Build Command:** pip install -r requirements.txt
- **Start Command:** python app.py
